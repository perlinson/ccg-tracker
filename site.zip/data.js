// CCG Games Data - 追踪近2年内将要上线的CCG游戏
const ccgGamesData = [
  {
    id: "star-wars-digital-ccg",
    name: "Star Wars Digital CCG",
    nameCn: "星球大战数字卡牌游戏",
    developer: "迪士尼 / 卢卡斯影业",
    expectedRelease: "2025年末 - 2026年",
    status: "开发中",
    description: "基于星球大战IP的数字集换式卡牌游戏，将融合经典的星球大战元素与创新的卡牌战斗机制。",
    features: [
      "星球大战IP授权",
      "数字集换式卡牌机制",
      "经典角色和阵营",
      "多人在线对战"
    ],
    videos: [
      {
        title: "官方预告片",
        url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        thumbnail: "https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg"
      },
      {
        title: "游戏演示视频",
        url: "https://www.youtube.com/watch?v=example",
        thumbnail: "https://img.youtube.com/vi/example/mqdefault.jpg"
      }
    ],
    lastUpdated: "2026-02-01"
  },
  {
    id: "riftbound",
    name: "Riftbound",
    nameCn: "裂隙绑定",
    developer: "独立开发团队",
    expectedRelease: "2026年 (扩展包 Spiritforged)",
    status: "已上线，持续更新",
    description: "一款独特的数字卡牌游戏，以其创新的召唤机制和深度的策略玩法著称。",
    features: [
      "独特的召唤机制",
      "策略性强的战斗系统",
      "丰富的卡牌组合",
      "定期扩展内容"
    ],
    videos: [
      {
        title: "Riftbound 扩展预览",
        url: "https://www.youtube.com/watch?v=example2",
        thumbnail: "https://img.youtube.com/vi/example2/mqdefault.jpg"
      }
    ],
    lastUpdated: "2026-02-01"
  },
  {
    id: "disney-lorcana-digital",
    name: "Disney Lorcana Digital",
    nameCn: "迪士尼洛卡纳数字版",
    developer: "Ravensburger",
    expectedRelease: "2025-2026年 (数字版)",
    status: "实体卡牌已上线，数字版开发中",
    description: "迪士尼洛卡纳的数字版本，将迪士尼经典角色与创新的卡牌游戏机制相结合。",
    features: [
      "迪士尼IP授权",
      "魔法与冒险主题",
      "精美的卡牌设计",
      "跨平台游戏体验"
    ],
    videos: [
      {
        title: "Lorcana 数字版概念展示",
        url: "https://www.youtube.com/watch?v=example3",
        thumbnail: "https://img.youtube.com/vi/example3/mqdefault.jpg"
      }
    ],
    lastUpdated: "2026-02-01"
  },
  {
    id: "overpower-reboot",
    name: "OverPower Reboot",
    nameCn: "OverPower 重启版",
    developer: "独立团队 (Kickstarter众筹)",
    expectedRelease: "2025年",
    status: "众筹完成，开发中",
    description: "90年代经典CCG OverPower的现代重启版，保留了原作的核心机制并进行了现代化改进。",
    features: [
      "90年代经典回归",
      "独特的卡牌机制",
      "现代画面风格",
      "竞技性对战"
    ],
    videos: [
      {
        title: "OverPower 重启版预告",
        url: "https://www.youtube.com/watch?v=example4",
        thumbnail: "https://img.youtube.com/vi/example4/mqdefault.jpg"
      }
    ],
    lastUpdated: "2026-02-01"
  },
  {
    id: "yugioh-new-game",
    name: "Yu-Gi-Oh! New Game",
    nameCn: "游戏王新作",
    developer: "Konami",
    expectedRelease: "2025-2026年",
    status: "官方宣布开发中",
    description: "游戏王系列的正统新作，将融合经典的游戏王元素与新技术。",
    features: [
      "经典IP新作",
      "融合新技术",
      "丰富的卡牌池",
      "竞技场比赛"
    ],
    videos: [
      {
        title: "Yu-Gi-Oh! 新作预告",
        url: "https://www.youtube.com/watch?v=example5",
        thumbnail: "https://img.youtube.com/vi/example5/mqdefault.jpg"
      }
    ],
    lastUpdated: "2026-02-01"
  },
  {
    id: "slay-the-spire-2",
    name: "Slay the Spire 2",
    nameCn: "杀戮尖塔 2",
    developer: "MegaCrit",
    expectedRelease: "2025-2026年",
    status: "开发中",
    description: "经典DBG(牌库构建游戏)杀戮尖塔的续作，将延续前作的roguelike与卡牌构建核心玩法。",
    features: [
      "roguelike + DBG玩法",
      "丰富的角色选择",
      "随机事件和奖励",
      "高度可重玩性"
    ],
    videos: [
      {
        title: "Slay the Spire 2 预告",
        url: "https://www.youtube.com/watch?v=example6",
        thumbnail: "https://img.youtube.com/vi/example6/mqdefault.jpg"
      }
    ],
    lastUpdated: "2026-02-01"
  },
  {
    id: "monster-train-2",
    name: "Monster Train 2",
    nameCn: "怪物火车 2",
    developer: "Shiny Shoe",
    expectedRelease: "2025年",
    status: "开发中",
    description: "怪物火车的续作，延续了独特的垂直战斗机制和卡牌构建玩法。",
    features: [
      "垂直战斗系统",
      "多路进攻机制",
      "丰富的种族组合",
      "策略深度高"
    ],
    videos: [
      {
        title: "Monster Train 2 预告",
        url: "https://www.youtube.com/watch?v=example7",
        thumbnail: "https://img.youtube.com/vi/example7/mqdefault.jpg"
      }
    ],
    lastUpdated: "2026-02-01"
  },
  {
    id: "flesh-and-blood-digital",
    name: "Flesh and Blood Digital",
    nameCn: "血肉之城 数字版",
    developer: "Legend Story Studios",
    expectedRelease: "2025-2026年",
    status: "实体卡牌火热，数字版开发中",
    description: "Flesh and Blood的官方数字版本，继承了实体卡牌快节奏、高对抗性的特点。",
    features: [
      "快节奏对战",
      "职业系统丰富",
      "高对抗性",
      "竞技导向"
    ],
    videos: [
      {
        title: "Flesh and Blood 数字版预告",
        url: "https://www.youtube.com/watch?v=example8",
        thumbnail: "https://img.youtube.com/vi/example8/mqdefault.jpg"
      }
    ],
    lastUpdated: "2026-02-01"
  }
];

// 导出数据
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { ccgGamesData };
}
